﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoReMiVRP
{
    class CityLocation
    {
        public static  float X = 0.0f;
        public static float Y = 0.0f;
        public static bool IsUtilized = false;
    }
}
