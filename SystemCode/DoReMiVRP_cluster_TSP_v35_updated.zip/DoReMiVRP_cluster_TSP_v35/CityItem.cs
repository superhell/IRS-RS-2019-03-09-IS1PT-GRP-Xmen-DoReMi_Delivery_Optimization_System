﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoReMiVRP
{
    internal class CityItem
    {
        public String City { get; set; }
        public float X { get; set; }
        public float Y { get; set; }
        public int Order { get; set; }
    }
}