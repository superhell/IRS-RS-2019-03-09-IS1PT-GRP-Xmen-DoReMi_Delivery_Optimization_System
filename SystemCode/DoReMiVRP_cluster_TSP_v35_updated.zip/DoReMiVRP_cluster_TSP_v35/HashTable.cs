﻿namespace Sys.Tool
{
    public class HashTable
    {
    }
}